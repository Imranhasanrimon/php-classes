<?php
  $curr_page = 'book';
?>
  <?php include './includes/head.php'; ?>
  <meta name="description" content="Get a professional insulation estimate for your home. Schedule your free in-home consultation with DMV Foam today.">
  <title>Book Your Free In-Home Insulation Consultation</title>
</head>
<body>
  <?php include './includes/header.php'; ?>
  <main class="main" role="main">
    <header class="page-header">
      <div class="container">
        <div class="container-inner">
          <h1>Book In-Home Consultation</h1>
        </div>
      </div>
    </header>
    <section class="section">
      <div class="container">
        <div class="container-inner">
          <!-- <div class="calendly-widget-toggler animate" style="display: flex; border: 1px solid rgba(26, 26, 26, 0.1); border-radius: 8px; box-shadow: 0 1px 8px 0 rgb(0 0 0 / 8%); max-width: 800px; margin-left: auto; margin-right: auto;">
            <div class="calendly-widget-toggler__item">
              <a class="calendly-widget-link active" href="/book-inhome-consultation.php">In-home Consultation</a>
            </div>
            <div class="calendly-widget-toggler__item">
              <a class="calendly-widget-link" href="/book-phone-consultation">Phone Consultation</a>
            </div>
          </div> -->
          <div class="ghl-wrapper">
            <iframe src="https://api.leadconnectorhq.com/widget/booking/irB8JEaPbRIeCnfRDF9y" style="width: 100%;border:none;overflow: hidden;" scrolling="no" id="irB8JEaPbRIeCnfRDF9y_1720540917237"></iframe>
          </div>
        </div>
      </div>
    </section>
    <section class="pre-footer">
      <div class="pre-footer__wave">
        <img src="./assets/svg/footer-wave.svg" alt="Wave">
      </div>
      <div class="pre-footer__main">
        <div class="container">
          <div class="container-inner">
            <h2 class="text-w title-big">Our mission is to provide the best service for all types of buildings. We want you to be surrounded by comfort, both at work and at home.</h2>
          </div>
        </div>
      </div>
    </section>
  </main>
  <?php include './includes/footer.php'; ?>
  <?php include './includes/svg.php'; ?>
  <script src="https://link.msgsndr.com/js/form_embed.js" type="text/javascript"></script>
  <?php include './includes/end.php'; ?>
