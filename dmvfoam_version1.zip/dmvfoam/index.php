<?php
  $curr_page = 'home';
?>
  <?php include './includes/head.php'; ?>
  <link rel="preload" as="image" href="/assets/images/new/intro-3.webp">
  <link rel="preload" as="image" href="/assets/svg/hero-bg.svg">
  <meta name="description" content="Looking for spray foam insulation contractors near you? DMV Foam is a leading insulation company in Washington, DC. Get a free estimate today.">
  <title>DMV Foam – Trusted Insulation Contractor Washington, DC</title>
</head>
<body>
  <?php include './includes/header.php'; ?>
  <main class="main" role="main">
    <section class="intro">
      <div class="container">
        <div class="container-inner intro__inner">
          <div class="row">
            <div class="column">
              <h1 class="title">Insulation Contractor Washington, DC</h1>
              <p class="paragraph">Your trusted Spray Insulation Conractor All over Washington, DC.</p>
            </div>
            <div class="column mobile-view">
              <div class="form-wrapper form-wrapper--intro" style="text-align: center;">
                <h3 class="h4 title">Request A Quote</h3>
                <a class="btn btn-blue" href="/book-phone-consultation">Get Free Quote</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <img class="intro__bg" src="./assets/svg/hero-bg.svg" alt="insulation washington dc">
    </section>
    <section id="get-quote" class="section anchor-target">
      <div class="container">
        <div class="container-inner">
          <div class="row mobile-view">
            <div class="column">
              <h2 class="title">Welcome to DMV Foam</h2>
              <p class="paragraph">We are Washington DC's most trusted spray foam insulation company. With over 16 years of insulation experience, we at DMV Foam has a reputation for providing practical, effective solutions at an affordable price.</p>
              <p class="paragraph">Guaranteed you'll not only get quality workmanship that delivers best results, but gives you peace of mind you deserve knowing you're working with the best <b>spray foam insulation contractor</b> all over DC.</p>
              <p class="paragraph">Get a free quotation now get your free estimate, let's convert your place into eco-friendly and wise.</p>
            </div>
            <div class="column">
              <img width="500" height="300" src="./assets/images/company-min.webp" alt="dc insulation contractor">
            </div>
          </div>
        </div>
      </div>
    </section>
    <section>
      <div class="container">
        <div class="container-inner">
          <img class="container-inner__wave-image" src="./assets/svg/wave-right.svg" width="1160" height="83" alt="insulation dc">
        </div>
      </div>
    </section>
    <section class="section">
      <div class="container">
        <div class="container-inner">
          <header class="heading">
            <h2 class="title">We Offer</h2>
            <p class="text-w">We offer our service for various types of buildings and structures.</p>
          </header>
          <div class="grid mobile-view">
            <div class="grid__item">
              <div class="expert-card">
                <header class="expert-card__header" style="background-image: url('../assets/images/commercial-service.webp')"></header>
                <div class="expert-card__main">
                  <h3>Spray Foam Roof Systems</h3>
                  <p>Cost-effective, long-lasting roofing solution: roofing foam. It works in any climate and is a great investment for any roof.</p>
                </div>
                <footer class="expert-card__footer">
                  <a class="btn btn-blue" href="./services#commercial">Learn More</a>
                </footer>
              </div>
            </div>
            <div class="grid__item">
              <div class="expert-card">
                <header class="expert-card__header" style="background-image: url('../assets/images/residental-service.webp')"></header>
                <div class="expert-card__main">
                  <h3>Residential</h3>
                  <p>Make your home feel more comfortable. Spray foam insulation allows your home heating and cooling units to work more efficiently. Get a reduction power costs as much at 35%  without losing efficiency and comfort.</p>
                </div>
                <footer class="expert-card__footer">
                  <a class="btn btn-blue" href="./services#residential">Learn More</a>
                </footer>
              </div>
            </div>
            <div class="grid__item">
              <div class="expert-card">
                <header class="expert-card__header" style="background-image: url('../assets/images/service-3.webp')"></header>
                <div class="expert-card__main">
                  <h3>Agriculture</h3>
                  <p>Saving agricultural business and operators for decades. Spray foam insulation protect your crops from damage, maintaining a sufficiently insulated building for your livestocks with less use of energy and fuel.</p>
                </div>
                <footer class="expert-card__footer">
                  <a class="btn btn-blue" href="./services#agriculture">Learn More</a>
                </footer>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section>
      <div class="container">
        <div class="container-inner">
          <img class="container-inner__wave-image" src="./assets/svg/wave-left.svg" width="1160" height="83" alt="Dmv Foam">
        </div>
      </div>
    </section>
    <section class="section">
      <div class="container">
        <div class="container-inner">
          <header class="heading">
            <h2>Full List of Services</h2>
          </header>
          <?php include './includes/serv-list.php'; ?>
        </div>
      </div>
    </section>
    <section>
      <div class="container">
        <div class="container-inner">
          <img class="container-inner__wave-image" src="./assets/svg/wave-right.svg" width="1160" height="83" alt="Attic Insulation dc">
        </div>
      </div>
    </section>
    <section class="section">
      <div class="container">
        <div class="container-inner">
          <header class="heading">
            <h2 class="title">Spray Foam Insulation</h2>
            <p class="text-w">We offer two types of foam insulation.</p>
          </header>
          <div class="row mobile-view">
            <div class="column">
              <div class="card">
                <header class="card__header" style="background-image: url('../assets/images/open-cell-info.webp')"></header>
                <div class="card__main">
                  <h3>Open Cell</h3>
                  <p>Open cell spray foam are cheaper than other insulation materials. It provides less dense and more flexible material. Best use for ceiling insulation and noise reduction.</p>
                </div>
                <footer class="card__footer">
                  <a class="btn btn-blue" href="./foam-insulation#open-cell">Learn More</a>
                </footer>
              </div>
            </div>
            <div class="column">
              <div class="card">
                <header class="card__header" style="background-image: url('../assets/images/closed-cell-info.webp')"></header>
                <div class="card__main">
                  <h3>Closed Cell</h3>
                  <p>More commonly used in barns and commercial buildings. Serves as an eco-friendly insulation option, closed cell foam provides airtight seal reducing your energy consumption and prevents mold growth, and strengthen building structure.</p>
                </div>
                <footer class="card__footer">
                  <a class="btn btn-blue" href="./foam-insulation#closed-cell">Learn More</a>
                </footer>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section>
      <div class="container">
        <div class="container-inner">
          <img class="container-inner__wave-image" src="./assets/svg/wave-left.svg" width="1160" height="83" alt="Foam">
        </div>
      </div>
    </section>
    <section class="section">
      <div class="container">
        <div class="container-inner">
          <header class="heading">
            <h2 class="title">Advantages</h2>
            <p class="text-w">Foam insulation has a number of advantages that provide a wide range of applications for this technology.</p>
          </header>
          <div class="benefits-list mobile-view">
            <div class="benefits-list__item">
              <div class="benefit-card">
                <div class="benefit-card__header benefit-card__header--color-curious">
                  <div class="benefit-card__header-inner">
                    <svg><use href="#icon-primer" /></svg>
                  </div>
                </div>
                <h3 class="h4">It Deters Moisture</h3>
                <p>Spray foam insulation is built to prevent outdoor moisture from infiltrating your house or building. <b>Attic insulation washington dc</b> creates an airtight barrier that prevents air leakage that could result in condensation or developing molds.</p>
              </div>
            </div>
            <div class="benefits-list__item">
              <div class="benefit-card">
                <div class="benefit-card__header benefit-card__header--color-emerald">
                  <div class="benefit-card__header-inner">
                    <svg><use href="#icon-thermometer" /></svg>
                  </div>
                </div>
                <h3 class="h4">It Improves Comfort</h3>
                <p><b>Spray Foam insulation Washington Dc</b> will equalize the temperatures across your house, reduces sound transmission and noice coming in and out your house, adding comfort and advantage to you and your family.</p>
              </div>
            </div>
            <div class="benefits-list__item">
              <div class="benefit-card">
                <div class="benefit-card__header benefit-card__header--color-shake">
                  <div class="benefit-card__header-inner">
                    <svg><use href="#icon-air-quality" /></svg>
                  </div>
                </div>
                <h3 class="h4">It Improves Indoor Air Quality</h3>
                <p>Spray Foam insulation creates an air seal, reducing penetration of dust, allergens, pollutants and other air contaminants  providing a cleaner air quality in your home.</p>
              </div>
            </div>
            <div class="benefits-list__item">
              <div class="benefit-card">
                <div class="benefit-card__header benefit-card__header--color-indigo">
                  <div class="benefit-card__header-inner">
                    <svg><use href="#icon-install" /></svg>
                  </div>
                </div>
                <h3 class="h4">It Is Easy to Install</h3>
                <p>Spray foam insulation is an alternative to traditional building insulation. Gives you a quick and easy fix to all your uncomfortable house issues within 24 hours.</p>
              </div>
            </div>
            <div class="benefits-list__item">
              <div class="benefit-card">
                <div class="benefit-card__header benefit-card__header--color-curious">
                  <div class="benefit-card__header-inner">
                    <svg><use href="#icon-clock" /></svg>
                  </div>
                </div>
                <h3 class="h4">It Lasts</h3>
                <p>100% quality guaranteed - attic insulation dc spray foam can last for more than 100 years, it won't compress, sag, or settle over time making your initial cost well worth the investment.</p>
              </div>
            </div>
            <div class="benefits-list__item">
              <div class="benefit-card">
                <div class="benefit-card__header benefit-card__header--color-emerald">
                  <div class="benefit-card__header-inner">
                    <svg><use href="#icon-brick" /></svg>
                  </div>
                </div>
                <h3 class="h4">It Provides Additional Strength to Buildings</h3>
                <p>Spray foam insulation High-density closed-cell spray foam insulation improves buildings strength and durability. It provides up to three times as much structural strength as other insulation options.</p>
              </div>
            </div>
            <div class="benefits-list__item">
              <div class="benefit-card">
                <div class="benefit-card__header benefit-card__header--color-shake">
                  <div class="benefit-card__header-inner">
                    <svg><use href="#icon-sound" /></svg>
                  </div>
                </div>
                <h3 class="h4">It Reduces Sound</h3>
                <p>Effective sound-absorbing qualities that blocks external noise from entering your property.</p>
              </div>
            </div>
            <div class="benefits-list__item">
              <div class="benefit-card">
                <div class="benefit-card__header benefit-card__header--color-indigo">
                  <div class="benefit-card__header-inner">
                    <svg><use href="#icon-save-money" /></svg>
                  </div>
                </div>
                <h3 class="h4">It Saves You Money</h3>
                <p>Reduce your energy bills, it  performs as both insulation and an air barrier, sealing every crack and crevice, reduces up to 50%, of your energy bills. Guaranteed to pay-off starting day one.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="section section--separate" style="margin: 0; padding-bottom: 0;">
      <div class="container">
        <div class="container-inner">
          <div class="map-card">
            <header class="map-card__header">
              <h2 class="title">Service Areas</h2>
              <div class="map-card__separator"></div>
              <ul class="lines-list">
			          <li><a href="/springfield-va">Springfield, VA</a></li>
                <li><a href="/falls-church-va">Falls Church, VA</a></li>
			          <li><a href="/bethesda-md">Bethesda, MD</a></li>
                <li><a href="/herndon-va">Herndon, VA</a></li>
				        <li><a href="/annandale-va">Annandale, VA</a></li>
				        <li><a href="/fairfax-va">Fairfax, VA</a></li>
				        <li><a href="/alexandria-va">Alexandria, VA</a></li>
			          <li><a href="https://dmvfoam.com/chantilly-va">Chantilly Va</a></li>
				        <li><a href="https://dmvfoam.com/woodbridge-va">Woodbridge, VA</a></li>
				        <li><a href="https://dmvfoam.com/arlington-va">Arlington, VA</a></li>
			          <li><a href="https://dmvfoam.com/culpeper-va">Culpeper, VA</a></li>
				        <li><a href="https://dmvfoam.com/gaithersburg-md">Gaithersburg, MD</a></li> 
				        <li><a href="https://dmvfoam.com/centreville-va">Centreville, VA</a></li>
				        <li><a href="https://dmvfoam.com/germantown-md">Germantown, MD</a></li>
				        <li><a href="https://dmvfoam.com/laurel-md">Laurel, MD</a></li>
			          <li><a href="https://dmvfoam.com/lorton-va">Lorton, VA</a></li>
				        <li><a href="https://dmvfoam.com/oakton-va">Oakton, VA</a></li>
				        <li><a href="https://dmvfoam.com/potomac-md">Potomac, MD</a></li>
			          <li><a href="https://dmvfoam.com/reston-va">Reston, VA</a></li>
			          <li><a href="https://dmvfoam.com/mclean-va">Mclean, VA</a></li>
				        <li><a href="https://dmvfoam.com/rockville-md">Rockville, VA</a></li>
				        <li><a href="https://dmvfoam.com/sterling-va">Sterling, VA</a></li>
			          <li><a href="https://dmvfoam.com/vienna-va">Vienna, VA</a></li>
                <li><a href="https://dmvfoam.com/ashburn-va">Ashburn, VA</a></li>
                <li><a href="https://dmvfoam.com/leesburg-va">Leesburg, VA</a></li>
                <li><a href="https://dmvfoam.com/manassas-va">Manassas, VA</a></li>
              </ul>
            </header>
            <div class="map-card__main">
              <iframe title="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7390.630968956823!2d-77.11664330163723!3d38.846714028565614!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89b7b392e333df4d%3A0xb3986a726fcfc1c1!2sDMV%20Foam!5e0!3m2!1sen!2sen!4v1668503337430!5m2!1sen!2sen" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="pre-footer">
      <div class="pre-footer__wave">
        <img src="./assets/svg/footer-wave.svg" alt="Wave">
      </div>
      <div class="pre-footer__main">
        <div class="container">
          <div class="container-inner">
            <h4 class="text-w title-big">Our mission is to provide the best service for all types of buildings. We want you to be surrounded by comfort, both at work and at home.</h4>
            <p><a class="btn btn-big btn-blue" href="/book-phone-consultation">Get a Quote</a></p>
          </div>
        </div>
      </div>
    </section>
  </main>
  <?php include './includes/footer.php'; ?>
  <?php include './includes/svg.php'; ?>
  
  <?php include './includes/end.php'; ?>
