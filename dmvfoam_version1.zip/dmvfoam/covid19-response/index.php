<?php
  $curr_page = 'covid';
?>
  <?php include '../includes/head.php'; ?>
  <!-- SEO Meta Tags -->
  <meta name="description" content="DMV Foam's comprehensive COVID-19 safety response. We continue providing insulation services with enhanced safety protocols, contactless consultations, and flexible policies to keep you safe.">
  <meta name="keywords" content="DMV Foam COVID-19, insulation services pandemic, contactless consultation, safe insulation work, COVID-19 protocols, home insulation safety">
  <meta name="author" content="DMV Foam">
  <meta name="robots" content="index, follow">
  
  <!-- Open Graph Meta Tags -->
  <meta property="og:title" content="DMV Foam COVID-19 Safety Response | Contactless Insulation Services">
  <meta property="og:description" content="Learn how DMV Foam adapted our insulation services during COVID-19 with enhanced safety protocols, contactless consultations, and flexible policies.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://dmvfoam.com/covid19-response">
  <meta property="og:site_name" content="DMV Foam">
  
  <!-- Twitter Card Meta Tags -->
  <meta name="twitter:card" content="summary">
  <meta name="twitter:title" content="DMV Foam COVID-19 Safety Response | Contactless Services">
  <meta name="twitter:description" content="Safe insulation services during COVID-19 with enhanced protocols and contactless consultations.">
  
  <!-- Additional SEO Meta Tags -->
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="canonical" href="https://dmvfoam.com/covid19-response">
  
  <title>DMV Foam COVID-19 Safety Measures  </title>
</head>
<body>
  <?php include '../includes/header.php'; ?>
  <main class="main" role="main">
    <header class="page-header">
      <div class="container">
        <div class="container-inner">
          <h1>Covid-19 Response</h1>
        </div>
      </div>
    </header>
    <section class="section section--separate" style="margin: 0; padding-bottom: 0;">
      <div class="container">
        <div class="container-inner">
          <p class="paragraph text-w">We continue to servce - with the impact of Covid-19 continuing to be felt worldwide, we wanted to update you on how we are currently navigating this unprecedented time.</p>
          <p class="paragraph text-w">Whilst keeping the health and safety of our team and clients are of utmost priority, we have been able to deal with the unexpected and quickly adapt to change and new ways of working quickly and easily to ensure we can continue offering you our service.</p>
          <p class="paragraph text-w">Actions we have taken include:</p>
          <ul class="list paragraph text-w">
            <li>Office staff have transitioned to work from home and are available between the hours of 9am – 5.00pm.</li>
            <li>We offer phone appointment option, or video calling, to ensure you see the same level of engagement from us that you usually receive.</li>
            <li>Digital transactions for all services. Paying for our services using digital transactions and receipts to minimize person-to-person contact during estimates, insulation work and other inspection.</li>
            <li>We offer flexible cancellation terms for all work going forward, due to evolving situation of Covid19,we offer fully flexible policies giving you peace of mind should you need to postpone projects you signed with us.</li>
            <li>Our team are continuously updated on any news updates and information. This guarantees we can use our expertise to help guide our customers whats best next course of action and decisions.</li>
            <li>In compliance with Recommendations from WHO. For work that is done outside of your home, we will ensure to keep a minimum distance of six feet between our team and household member so you don’t have to worry about running into a crew member while work is being completed.</li>
            <li>If If interior access is needed, you can discuss guidelines with us prior to site visit to avoid crew memeber coming into contact with household members.</li>
          </ul>
          <br>
          <p class="paragraph text-w">Our team are here to fully support you and are more than happy to offer guidance and free quotation. Click the button below to get started.</p>
          <p class="paragraph text-w">We look forward to hearing from you soon!</p>
          <p class="paragraph text-w">Keep safe!<br>DMV Foam.</p>
        </div>
      </div>
    </section>
    <section class="pre-footer">
      <div class="pre-footer__wave">
        <img src="../assets/svg/footer-wave.svg" alt="Wave">
      </div>
      <div class="pre-footer__main">
        <div class="container">
          <div class="container-inner">
            <h2 class="text-w title-big">Our mission is to provide the best service for all types of buildings. We want you to be surrounded by comfort, both at work and at home.</h2>
            <p><a class="btn btn-big btn-blue" href="/book-phone-consultation">Get a Quote</a></p>
          </div>
        </div>
      </div>
    </section>
  </main>
  <?php include '../includes/footer.php'; ?>
  <?php include '../includes/svg.php'; ?>
  <?php include '../includes/end.php'; ?>
