<?php
$api_token = '7ce44f29061174616279ceb558abe7ed59f2f123';
$company_domain = 'sterlingroofers';
$company_email = 'contact@dmvfoam.com';
$form_type = '';
$name = '';
$email = '';
$phone = '';
$address = '';
$day = '';
$time = '';
$message = '';

if (isset($_POST['type'])) {
  $form_type = $_POST['type'];
}
if (isset($_POST['name'])) {
  $name = $_POST['name'];
}
if (isset($_POST['email'])) {
  $email = $_POST['email'];
}
if (isset($_POST['phone'])) {
  $phone = $_POST['phone'];
}
if (isset($_POST['address'])) {
  $address = $_POST['address'];
}
if (isset($_POST['day'])) {
  $day = $_POST['day'];
}
if (isset($_POST['time'])) {
  $time = $_POST['time'];
}
if (isset($_POST['message'])) {
  $message = $_POST['message'];
}

$urlDeal = 'https://' . $company_domain . '.pipedrive.com/api/v1/deals?api_token=' . $api_token;
$urlPerson = 'https://' . $company_domain . '.pipedrive.com/api/v1/persons?api_token=' . $api_token;
$urlNotes = 'https://' . $company_domain . '.pipedrive.com/api/v1/notes?api_token=' . $api_token;
$urlActivity = 'https://' . $company_domain . '.pipedrive.com/api/v1/activities?api_token=' . $api_token;
$urlItemSearch = 'https://' . $company_domain . '.pipedrive.com/api/v1/itemSearch?api_token=' . $api_token;
$urlEncodeEmail = 'https://zhlavxa8fh.execute-api.us-east-1.amazonaws.com/Prod/rest/email-relay/encoded?customer-email=' . $email . '&company-email=' . $company_email;





// getters
function get_deal_title($type, $person_name, $person_address) {
  if ($type == 'phone-meeting') {
    return "".$person_name."";
  } elseif ($type == 'inhome-meeting') {
    return "".$person_name.": ".$person_address."";
  } elseif ($type == 'showroom-meeting') {
    return "".$person_name."";
  }
}

function get_activity_name($type, $person_name) {
  if ($type == 'phone-meeting') {
    return "15 min call: ".$person_name.'';
  } elseif ($type == 'inhome-meeting') {
    return "In-Home: ".$person_name.'';
  } elseif ($type == 'showroom-meeting') {
    return "Showroom: ".$person_name.'';
  }
}

function get_activity_type($type) {
  if ($type == 'phone-meeting') {
    return "phoneconsult";
  } elseif ($type == 'inhome-meeting') {
    return "inhome";
  } elseif ($type == 'showroom-meeting') {
    return "showroom";
  }
}

function get_activity_duration($type) {
  if ($type == 'phone-meeting') {
    return "00:15";
  } elseif ($type == 'inhome-meeting') {
    return "00:45";
  } elseif ($type == 'showroom-meeting') {
    return "00:45";
  }
}


// ajax get
function get_encoded_email($url) {
  $encoded_email = "";
  //GET request
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  $output = curl_exec($ch);
  curl_close($ch);
  // Create an array from the data that is sent back from the API
  // As the original content from server is in JSON format, you need to convert it to a PHP array
  $result = json_decode($output, true);

  if (!empty($result['encoded_email'])) {
    $encoded_email = $result['encoded_email'];
  } else {
    $encoded_email = $result['message'];
  }

  return $encoded_email;
}

function get_encoded_phone($encoded_email, $phone) {
  $trimmer_phone = str_replace(' ', '', $phone);
  $trimmer_phone = str_replace('(', '', $trimmer_phone);
  $trimmer_phone = str_replace(')', '', $trimmer_phone);
  $trimmer_phone = str_replace('-', '', $trimmer_phone);
  $trimmer_phone = str_replace('+1', '', $trimmer_phone);
  $domain = strstr($encoded_email, '@');
  return $trimmer_phone.''.$domain;
}

function get_person($url_item_search) {
  $person_id = "";
  //GET request
  $ch_get_person = curl_init();
  curl_setopt($ch_get_person, CURLOPT_URL, $url_item_search);
  curl_setopt($ch_get_person, CURLOPT_RETURNTRANSFER, true);
  $output_get_person = curl_exec($ch_get_person);
  curl_close($ch_get_person);
  // Create an array from the data that is sent back from the API
  // As the original content from server is in JSON format, you need to convert it to a PHP array
  $result_get_person = json_decode($output_get_person, true);

  if (!empty($result_get_person['data']['items'])) {
    // person founded
    $person_id = $result_get_person['data']['items'][0]['item']['id'];
  }

  return $person_id;
}

function get_person_deal($person_id) {
  $deal_id = "";
  $query_url = 'https://sterlingroofers.pipedrive.com/api/v1/persons/'. $person_id .'/deals?api_token=7ce44f29061174616279ceb558abe7ed59f2f123&status=open';

  $ch_get_person_deal = curl_init();
  curl_setopt($ch_get_person_deal, CURLOPT_URL, $query_url);
  curl_setopt($ch_get_person_deal, CURLOPT_RETURNTRANSFER, true);
  $output_get_person_deal = curl_exec($ch_get_person_deal);
  curl_close($ch_get_person_deal);
  $result_get_person_deal = json_decode($output_get_person_deal, true);

  if (!empty($result_get_person_deal['data'])) {
    $deal_id = $result_get_person_deal['data'][0]['id'];
  }

  return $deal_id;
}


// ajax update
function update_deal_address($deal_id, $person_address, $person_name, $type) {
  $data = array(
    'title' => get_deal_title($type, $person_name, $person_address),
    'd4387dfc6db6ca95baf8b9a837dfc58c71a40f81' => $person_address
  );
  $query_url = 'https://sterlingroofers.pipedrive.com/api/v1/deals/' . $deal_id . '?api_token=7ce44f29061174616279ceb558abe7ed59f2f123';
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $query_url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
  curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
  $output = curl_exec($ch);
  curl_close($ch);
  $result = json_decode($output, true);

  return $result;
}



// ajax create
function create_person($person_name, $person_email, $person_phone, $url_person, $real_email, $encoded_phone) {
  $person = array(
    'name' => $person_name,
    'email' => $person_email,
    'phone' => $person_phone,
    'fdb58254990a302249502c8d841c14805229cc05' => $real_email,
    'a9d11507faa73db0361ca11beae4ca1aba1620bd' => $encoded_phone
  );
  $ch_person = curl_init();
  curl_setopt($ch_person, CURLOPT_URL, $url_person);
  curl_setopt($ch_person, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch_person, CURLOPT_POST, true);
  curl_setopt($ch_person, CURLOPT_POSTFIELDS, $person);
  $output_person = curl_exec($ch_person);
  curl_close($ch_person);
  $result_person = json_decode($output_person, true);
  return $result_person;
}

function create_deal($type, $person_name, $person_address, $person_id, $url_deal) {
  $deal = array(
    'title' => get_deal_title($type, $person_name, $person_address),
    'person_id' => $person_id,
    'pipeline_id' => '8',
    'd4387dfc6db6ca95baf8b9a837dfc58c71a40f81' => $person_address
  );
  $ch_deal = curl_init();
  curl_setopt($ch_deal, CURLOPT_URL, $url_deal);
  curl_setopt($ch_deal, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch_deal, CURLOPT_POST, true);
  curl_setopt($ch_deal, CURLOPT_POSTFIELDS, $deal);
  $output_deal = curl_exec($ch_deal);
  curl_close($ch_deal);
  $result_deal = json_decode($output_deal, true);
  return $result_deal;
}

function create_note($persone_message, $deal_id, $url_note) {
  $note = array(
    'content' => $persone_message,
    'deal_id' => $deal_id
  );
  $ch_note = curl_init();
  curl_setopt($ch_note, CURLOPT_URL, $url_note);
  curl_setopt($ch_note, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch_note, CURLOPT_POST, true);
  curl_setopt($ch_note, CURLOPT_POSTFIELDS, $note);
  $output_note = curl_exec($ch_note);
  curl_close($ch_note);
  $result_note = json_decode($output_note, true);
  return $result_note;
}

function create_activity($type, $person_name, $event_type, $deal_id, $url_activity, $activity_day, $activity_time) {
  $activity = array(
    'subject' => get_activity_name($type, $person_name),
    'type' => $event_type,
    'deal_id' => $deal_id,
    'due_date' => $activity_day,
    'due_time' => $activity_time,
    'duration' => get_activity_duration($type)
  );
  $ch_activity = curl_init();
  curl_setopt($ch_activity, CURLOPT_URL, $url_activity);
  curl_setopt($ch_activity, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch_activity, CURLOPT_POST, true);
  curl_setopt($ch_activity, CURLOPT_POSTFIELDS, $activity);
  $output_activity = curl_exec($ch_activity);
  curl_close($ch_activity);
  $result_activity = json_decode($output_activity, true);
  return $result_activity;
}




$encoded_email = get_encoded_email($urlEncodeEmail);
$encoded_phone = get_encoded_phone($encoded_email, $phone);
$urlPersonSearch  = 'https://' . $company_domain . '.pipedrive.com/api/v1/persons/search?api_token=' . $api_token .'&term=' . $encoded_email;
$get_person_response_id = get_person($urlPersonSearch);

if (empty($get_person_response_id)) {
  // person not found
  $create_person_response = create_person($name, $encoded_email, $phone, $urlPerson, $email, $encoded_phone);
  if (!empty($create_person_response['data']['id'])) {
     $create_deal_response = create_deal($form_type, $name, $address, $create_person_response['data']['id'], $urlDeal);
     if (!empty($create_deal_response['data']['id'])) {
      if ($message != '') {
        $create_note_response = create_note($message, $create_deal_response['data']['id'], $urlNotes);
      }
      $create_activity_response = create_activity($form_type, $name, get_activity_type($form_type), $create_deal_response['data']['id'], $urlActivity, $day, $time);
      echo json_encode(array(
        'success' => 'true',
        'person_founded' => 'false',
        'deal_founded' => 'false',
        'person_id'  => $create_person_response['data']['id'],
        'deal_id' => $create_deal_response['data']['id'],
        'result_note'  => $create_note_response,
        'result_activity'  => $create_activity_response,
        'encoded_email' => $encoded_email,
        'encoded_phone' => $encoded_phone
      ));
    }
  }
} else {
  // person founded
  $get_person_deal_response_id = get_person_deal($get_person_response_id);

  if (empty($get_person_deal_response_id)) {
    // deal not found
    $create_deal_response = create_deal($form_type, $name, $address, $get_person_response_id, $urlDeal);
    if (!empty($create_deal_response['data']['id'])) {
      if ($message != '') {
        $create_note_response = create_note($message, $create_deal_response['data']['id'], $urlNotes);
      }
      $create_activity_response = create_activity($form_type, $name, get_activity_type($form_type), $create_deal_response['data']['id'], $urlActivity, $day, $time);
      echo json_encode(array(
        'success' => 'true',
        'person_founded' => 'true',
        'deal_founded' => 'false',
        'person_id'  => $get_person_response_id,
        'deal_id' => $create_deal_response['data']['id'],
        'result_note'  => $create_note_response,
        'result_activity'  => $create_activity_response,
        'encoded_email' => $encoded_email,
        'encoded_phone' => $encoded_phone
      ));
    }
  } else {
    // deal founded
    if ($message != '') {
      $create_note_response = create_note($message, $get_person_deal_response_id, $urlNotes);
    }
    $create_activity_response = create_activity($form_type, $name, get_activity_type($form_type), $get_person_deal_response_id, $urlActivity, $day, $time);
    if ($form_type == 'inhome-meeting') {
      $update_deal_address_response = update_deal_address($get_person_deal_response_id, $address, $name, $form_type);
    }
    echo json_encode(array(
      'success' => 'true',
      'person_founded' => 'true',
      'deal_founded' => 'true',
      'person_id'  => $get_person_response_id,
      'deal_id' => $get_person_deal_response_id,
      'result_note'  => $create_note_response,
      'result_activity'  => $create_activity_response,
      'result_update_address'  => $update_deal_address_response,
      'encoded_email' => $encoded_email,
      'encoded_phone' => $encoded_phone
    ));
  }
}
