<?php
$requestBody = file_get_contents('php://input');
$requestData = json_decode($requestBody, true);
$password = $requestData['pass'];

$correctPassword = 'borja';
$success = false;

if ($password === $correctPassword) {
  $success = true;
}

$response = array('success' => $success);
header('Content-Type: application/json');
echo json_encode($response);
?>