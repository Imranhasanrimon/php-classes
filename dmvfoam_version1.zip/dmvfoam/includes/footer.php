<footer class="footer">
  <div class="container">
    <div class="container-inner footer__inner">
      <div class="footer__item">
        <div class="footer__row">
          <svg class="footer-logo"><use href="#icon-logo" /></svg>
        </div>
        <div class="footer__row">
          <p style="line-height: 1.2;"><small>Copyright © DMV Foam <?php echo date("Y"); ?><br>All Rights Reserved<br><br>3701 S. George Mason Drive, #1017,<br>Falls Church, VA 22041</small></p>
        </div>
        <div class="footer__row">
          <ul class="simple-list">
            <li><a class="icon-link" href="tel:+15719778247"><svg><use href="#icon-phone" /></svg><span>(571) 977-8247</span></a></li>
          </ul>
        </div>
      </div>
      <div class="footer__item">
        <h4 class="title">Finance You Project!</h4>
        <p style="margin-bottom: 18px;">Getting the money you need for your next home improvement project made simple. View, Compare and Apply in seconds without affecting your credit score. It's that easy!</p>
        <p><a class="btn btn-blue" href="https://www.enhancify.com/cdaa-inc-financing-offers" target="_blank">Apply</a></p>
      </div>
      <div class="footer__item">
        <h4 class="title">Pages</h4>
          <ul class="simple-list">
            <li>
              <a href="/">Home</a>
            </li>
            <li>
              <a href="/services">Services</a>
            </li>
            <li>
              <a href="/foam-insulation">Foam&nbsp;Insulation</a>
            </li>
            <li>
              <a href="/service-areas">Service&nbsp;Areas</a>
            </li>
            <li>
              <a href="/book-phone-consultation">Get a Quote</a>
            </li>
            <li>
              <a href="/covid19-response">Covid-19&nbsp;Response</a>
            </li>
          </ul>
      </div>
      <div class="footer__item">
        <h4 class="title">Socials</h4>
        <ul class="social-list" style="margin-bottom: 20px;">
          <li><a href="https://www.facebook.com/people/DMV-Foam/100067044187664/" rel="nofollow" target="_blank" aria-label="Facebook"><svg><use href="#icon-facebook" /></svg></a></li>
          <li><a href="https://www.houzz.com/pro/webuser-535415571/dmv-foam" rel="nofollow" target="_blank" aria-label="Houzz"><svg><use href="#icon-houzz" /></svg></a></li>
          <li><a href="https://maps.app.goo.gl/qS9KhFsLjT54sQGL6" rel="nofollow" target="_blank" aria-label="Google Map"><svg><use href="#icon-google-business" /></svg></a></li>
        </ul>
        <a class="fz-s" href="/sitemap.xml">Sitemap</a>
      </div>
    </div>
  </div>
  <!-- Generated using https://microdatagenerator.org/localbusiness-microdata-generator/ -->
<script type="application/ld+json">
{
	"@context": "https://schema.org",
	"@type": "GeneralContractor",
	"name": "DMV Foam",
	"address": {
		"@type": "PostalAddress",
		"streetAddress": "3701 S George Mason Dr Apt 1017",
		"addressLocality": "Falls Church",
		"addressRegion": "VA",
		"postalCode": "22041"
	},
	"image": "https://dmvfoam.com/logo.webp",
	"email": "conatct@dmvfoam.com",
	"telePhone": "5719778247",
	"url": "https://dmvfoam.com",
	"paymentAccepted": [ "cash", "check", "credit card", "invoice", "paypal" ],
	"openingHours": "Mo,Tu,We,Th,Fr,Sa 07:00-20:00",
	"openingHoursSpecification": [ {
		"@type": "OpeningHoursSpecification",
		"dayOfWeek": [
			"Monday",
			"Tuesday",
			"Wednesday",
			"Thursday",
			"Friday",
			"Saturday"
		],
		"opens": "07:00",
		"closes": "20:00"
	} ],
	"geo": {
		"@type": "GeoCoordinates",
		"latitude": "38.844014193371585",
		"longitude": "-77.114373126986"
	},
	"priceRange":"$"

}
</script>

</footer>

<div id="modal-container">
  <div class="modal-background">
    <div class="modal">
      <div class="modal-inner">
        <button class="modal-close"><svg class="modal-close__svg"><use class="modal-close__use" href="#svg-close" /></svg></button>
        <h4 class="h3 title-big">Financing up to <span>$250,000</span> for Home Improvement!</h4>
        <a class="modal-link btn btn-blue" href="https://www.enhancify.com/cdaa-inc-financing-offers" target="_blank">Finance Now</a>
      </div>
    </div>
  </div>
</div>