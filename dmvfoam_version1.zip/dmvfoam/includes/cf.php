<form id="cf" class="cf animate" method="POST">
  <div class="cf__row-list">
    <div class="cf__row cf__row--name">
      <label for="name" class="cf__label">Name</label>
      <input id="name" class="cf__input" type="text" name="name">
      <div class="cf__alert cf__alert--name"></div>
    </div>
    <div class="cf__row cf__row--email">
      <label for="email" class="cf__label">Email</label>
      <input id="email" class="cf__input" type="email" name="email">
      <div class="cf__alert cf__alert--email"></div>
    </div>
    <div class="cf__row cf__row--phone">
      <label for="phone" class="cf__label">Phone</label>
      <input id="phone" class="cf__input" type="tel" name="phone">
      <div class="cf__alert cf__alert--phone"></div>
    </div>
    <div class="cf__row cf__row--message">
      <label for="message" class="cf__label">Message</label>
      <textarea id="message" class="cf__input cf__input--textarea" name="message"></textarea>
      <div class="cf__alert cf__alert--message"></div>
    </div>
    <div class="cf__row cf__row--buttons">
      <!-- <button id="goto-inhome-button" class="btn btn-blue" type="button">In-Home<br>Consultation</button> -->
      <button id="goto-phone-button" class="btn btn-blue" type="button">Next Step</button>
    </div>
  </div>
</form>