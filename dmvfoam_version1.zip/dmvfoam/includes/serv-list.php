<div class="grid-4">
  <div class="serv-card">
    <div class="serv-card__icon">
      <svg style="fill: #22A3DA;"><use href="#icon-install" /></svg>
    </div>
    <h3 class="h5">Home Energy Audit</h3>
  </div>
  <div class="serv-card">
    <div class="serv-card__icon">
      <svg style="fill: #44c877;"><use href="#icon-install" /></svg>
    </div>
    <h3 class="h5">Attic Insulation</h3>
  </div>
  <div class="serv-card">
    <div class="serv-card__icon">
      <svg style="fill: #3FBCCC;"><use href="#icon-install" /></svg>
    </div>
    <h3 class="h5">Crawl Space Insulation</h3>
  </div>
  <div class="serv-card">
    <div class="serv-card__icon">
      <svg style="fill: #3A63CC;"><use href="#icon-install" /></svg>
    </div>
    <h3 class="h5">Cantilever Insulation</h3>
  </div>
  <div class="serv-card">
    <div class="serv-card__icon">
      <svg style="fill: #22A3DA;"><use href="#icon-install" /></svg>
    </div>
    <h3 class="h5">Wall Insulation</h3>
  </div>
  <div class="serv-card">
    <div class="serv-card__icon">
      <svg style="fill: #44c877;"><use href="#icon-install" /></svg>
    </div>
    <h3 class="h5">Garage Ceiling Insulation</h3>
  </div>
  <div class="serv-card">
    <div class="serv-card__icon">
      <svg style="fill: #3FBCCC;"><use href="#icon-install" /></svg>
    </div>
    <h3 class="h5">Roof Foam Coating</h3>
  </div>
  <div class="serv-card">
    <div class="serv-card__icon">
      <svg style="fill: #3A63CC;"><use href="#icon-install" /></svg>
    </div>
    <h3 class="h5">Blown-In Insulation</h3>
  </div>
  <div class="serv-card">
    <div class="serv-card__icon">
      <svg style="fill: #22A3DA;"><use href="#icon-install" /></svg>
    </div>
    <h3 class="h5">Cellulose Insulation</h3>
  </div>
  <div class="serv-card">
    <div class="serv-card__icon">
      <svg style="fill: #44c877;"><use href="#icon-install" /></svg>
    </div>
    <h3 class="h5">Fiberglass Insulation</h3>
  </div>
  <div class="serv-card">
    <div class="serv-card__icon">
      <svg style="fill: #3FBCCC;"><use href="#icon-install" /></svg>
    </div>
    <h3 class="h5">Mineral Wool Insulation</h3>
  </div>
  <div class="serv-card">
    <div class="serv-card__icon">
      <svg style="fill: #3A63CC;"><use href="#icon-install" /></svg>
    </div>
    <h3 class="h5">Fi-Foil's TBB System</h3>
  </div>
  <div class="serv-card">
    <div class="serv-card__icon">
      <svg style="fill: #22A3DA;"><use href="#icon-install" /></svg>
    </div>
    <h3 class="h5">Sound Insulation</h3>
  </div>
  <div class="serv-card">
    <div class="serv-card__icon">
      <svg style="fill: #44c877;"><use href="#icon-install" /></svg>
    </div>
    <h3 class="h5">Window Tinting</h3>
  </div>
</div>