<header class="header">
  <div class="container">
    <div class="header__inner">
      <div class="header__item">
        <a class="logo" href="../">
          <svg class="logo__svg">
            <use href="#icon-logo">
          </svg>
          <div class="logo__tm">TM</div>
        </a>
      </div>
      <div class="header__item">
        <nav class="nav">
          <ul class="nav-list">
            <li class="nav-list__item">
              <a class="nav-link <?php if($curr_page == 'home') { echo 'active'; } ?>" href="/">Home</a>
            </li>
            <li class="nav-list__item">
              <a class="nav-link <?php if($curr_page == 'services') { echo 'active'; } ?>" href="/services">Services</a>
            </li>
            <li class="nav-list__item">
              <a class="nav-link <?php if($curr_page == 'insulation') { echo 'active'; } ?>" href="/foam-insulation">Foam&nbsp;Insulation</a>
            </li>
            <li class="nav-list__item">
              <a class="nav-link <?php if($curr_page == 'areas') { echo 'active'; } ?>" href="/service-areas">Service&nbsp;Areas</a>
            </li>
            <li class="nav-list__item">
              <a class="nav-link <?php if($curr_page == 'blog') { echo 'active'; } ?>" href="/blog">Blog</a>
            </li>
            <li class="nav-list__item">
              <span class="nav-link nav-link--toggler <?php if($curr_page == 'book') { echo 'active'; } ?>">Book Consultation</span>
              <ul class="inner-nav-list">
                <li><a class="inner-nav-link" href="/book-phone-consultation">Phone Consultation</a></li>
                <li><span class="inner-nav-link goto-inhome">Office Use</span></li>
              </ul>
            </li>
          </ul>
        </nav>
      </div>
      <div class="header__item">
        <a class="gta-button header-button" href="tel:+15719778247">
          <svg><use href="#icon-phone"></svg>
          <span>(571)&nbsp;977-8247</span>
        </a>
      </div>
      <div class="header__item">
        <button class="burger-button js--nav-toggler" aria-label="Menu">
          <span></span>
          <span></span>
          <span></span>
        </button>
      </div>
    </div>
  </div>
</header>