  <script>
    const toggleNav=e=>{e.preventDefault();let t=document.querySelector("html");t.classList.contains("st--nav-open")?t.classList.remove("st--nav-open"):t.classList.add("st--nav-open")};document.querySelectorAll(".js--nav-toggler").forEach(e=>{e.addEventListener("click",toggleNav)});const scrollToAnchor=e=>{e.preventDefault();let t=Math.max(document.documentElement.clientWidth||0,window.innerWidth||0),o=t>959?61:0,n=document.querySelector(e.target.getAttribute("href"));window.scroll({top:n.offsetTop-o,left:0,behavior:"smooth"})};function toggleSubNav(e){window.innerWidth<1199&&(e.preventDefault(),e.target.closest(".nav-list__item").querySelector(".inner-nav-list").classList.toggle("st--active"))}async function gotoInHome(e){e.preventDefault();let t=prompt("Admin access:");if(!t){alert("No password provided.");return}try{let o={method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({pass:t})},n=await fetch("/cip.php",o),a=await n.json();a.success&&(window.location.href="https://dmvfoam.com/book-inhome-consultation.php")}catch(l){console.error("Error:",l)}}function showFinancingModal(){let e=sessionStorage.getItem("financing-modal");null===e&&(document.querySelector("body").classList.add("modal-active"),document.querySelector("#modal-container").classList.add("two"))}function hideFinancingModal(e){("modal-background"===e.target.className||"modal-close"===e.target.className||"modal-close__svg"===e.target.className.baseVal||"modal-close__use"===e.target.className.baseVal)&&(document.querySelector("#modal-container").classList.add("out"),document.querySelector("body").classList.remove("modal-active"),sessionStorage.setItem("financing-modal",!0))}function onClickFinancingButton(e){e.preventDefault(),window.open("https://www.enhancify.com/cdaa-inc-financing-offers","_blank").focus(),document.querySelector("#modal-container").classList.add("out"),document.querySelector("body").classList.remove("modal-active"),sessionStorage.setItem("financing-modal",!0)}document.querySelectorAll(".scroll").forEach(e=>{e.addEventListener("click",scrollToAnchor)}),window.addEventListener("load",function(){document.querySelector(".nav-link--toggler").addEventListener("click",toggleSubNav)}),window.addEventListener("load",function(){document.querySelector(".goto-inhome").addEventListener("click",gotoInHome)}),window.addEventListener("load",function(){document.querySelector("#modal-container").addEventListener("click",hideFinancingModal),document.querySelector(".modal-link").addEventListener("click",onClickFinancingButton),setTimeout(showFinancingModal,55e3)});
  </script>
<script>
function loadAnalyticsScript() {
    var script = document.createElement('script');
    script.src = 'https://www.googletagmanager.com/gtag/js?id=G-S1J9KHG64X';
    script.async = true;
    document.head.appendChild(script);

    script.onload = function() {
        var inlineScript = document.createElement('script');
        inlineScript.text = `
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-S1J9KHG64X');
        `;
        document.head.appendChild(inlineScript);
    };
}

window.addEventListener('load', function() {
    setTimeout(loadAnalyticsScript, 3000);
});
</script>
</body>
</html>