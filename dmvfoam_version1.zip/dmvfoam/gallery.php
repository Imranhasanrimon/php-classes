<?php
  $curr_page = 'gallery';
?>
  <?php include './includes/head.php'; ?>
  <link rel="stylesheet" href="/assets/styles/owl.carousel.min.css">
  <link rel="stylesheet" href="/assets/styles/owl.theme.default.min.css">
  <link rel="stylesheet" href="/assets/styles/magnific-popup.min.css">
  <meta name="description" content="">
  <title>DMV Foam - Gallery</title>
</head>
<body>
  <?php include './includes/header.php'; ?>
  <main class="main" role="main">
    <header class="page-header">
      <div class="container">
        <div class="container-inner">
          <h1>Gallery</h1>
        </div>
      </div>
    </header>
    <section class="section" style="margin-bottom:0;">
      <div class="container">
        <div class="container-inner">
          <header class="heading">
            <h2 class="title">Check out our latest work</h2>
          </header>
          <div class="slark-gallery">
            <div class="owl-carousel">
              <div>
                <div class="owl-card">
                  <div class="owl-card__item"><img class="image-link" href="./assets/images/spray/spray-foam-1.webp" src="./assets/images/spray/spray-foam-1min.webp" alt="Spray Foam Insulation Project Example #1"></div>
                  <div class="owl-card__item"><img class="image-link" href="./assets/images/spray/spray-12.webp" src="./assets/images/spray/spray-12.webp" alt="Spray Foam Insulation Project Example #2"></div>
                  <div class="owl-card__item"><img class="image-link" href="./assets/images/spray/spray-foam-17.webp" src="./assets/images/spray/spray-foam-17.webp" alt="Spray Foam Insulation Project Example #3"></div>
                  <div class="owl-card__item"><img class="image-link" href="./assets/images/spray/spray-10.webp" src="./assets/images/spray/spray-10.webp" alt="Spray Foam Insulation Project Example #4"></div>
                  <div class="owl-card__item"><img class="image-link" href="./assets/images/spray/spray-2.webp" src="./assets/images/spray/spray-2.webp" alt="Spray Foam Insulation Project Example #5"></div>
                  <div class="owl-card__item"><img class="image-link" href="./assets/images/spray/spray-4.webp" src="./assets/images/spray/spray-4.webp" alt="Spray Foam Insulation Project Example #6"></div>
                  <div class="owl-card__item"><img class="image-link" href="./assets/images/spray/spray-5.webp" src="./assets/images/spray/spray-5.webp" alt="Spray Foam Insulation Project Example #7"></div>
                  <div class="owl-card__item"><img class="image-link" href="./assets/images/spray/spray-17.webp" src="./assets/images/spray/spray-17.webp" alt="Spray Foam Insulation Project Example #8"></div>
                </div>
              </div>
              <div>
                <div class="owl-card">
                  <div class="owl-card__item"><img class="image-link" href="./assets/images/spray/spray-6.webp" src="./assets/images/spray/spray-6.webp" alt="Spray Foam Insulation Project Example #9"></div>
                  <div class="owl-card__item"><img class="image-link" href="./assets/images/spray/spray-8.webp" src="./assets/images/spray/spray-8.webp" alt="Spray Foam Insulation Project Example #10"></div>
                  <div class="owl-card__item"><img class="image-link" href="./assets/images/spray/spray-foam-18.webp" src="./assets/images/spray/spray-foam-18.webp" alt="Spray Foam Insulation Project Example #11"></div>
                  <div class="owl-card__item"><img class="image-link" href="./assets/images/spray/spray-13.webp" src="./assets/images/spray/spray-13.webp" alt="Spray Foam Insulation Project Example #12"></div>
                  <div class="owl-card__item"><img class="image-link" href="./assets/images/spray/spray-15.webp" src="./assets/images/spray/spray-15.webp" alt="Spray Foam Insulation Project Example #13"></div>
                  <div class="owl-card__item"><img class="image-link" href="./assets/images/spray/spray-7.webp" src="./assets/images/spray/spray-7.webp" alt="Spray Foam Insulation Project Example #14"></div>
                  <div class="owl-card__item"><img class="image-link" href="./assets/images/spray/spray-18.webp" src="./assets/images/spray/spray-18.webp" alt="Spray Foam Insulation Project Example #15"></div>
                  <div class="owl-card__item"><img class="image-link" href="./assets/images/spray/spray-9.webp" src="./assets/images/spray/spray-9.webp" alt="Spray Foam Insulation Project Example #16"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="pre-footer">
      <div class="pre-footer__wave">
        <img src="./assets/svg/footer-wave.svg" alt="Wave">
      </div>
      <div class="pre-footer__main">
        <div class="container">
          <div class="container-inner">
            <h2 class="text-w title-big">Our mission is to provide the best service for all types of buildings. We want you to be surrounded by comfort, both at work and at home.</h2>
            <p><a class="btn btn-big btn-blue" href="/book-phone-consultation">Get a Quote</a></p>
          </div>
        </div>
      </div>
    </section>
  </main>
  <?php include './includes/footer.php'; ?>
  <?php include './includes/svg.php'; ?>
  <script src="./assets/scripts/jquery.min.js"></script>
  <script src="./assets/scripts/owl.carousel.min.js"></script>
  <script src="./assets/scripts/jquery.magnific-popup.min.js"></script>
  <script>
    $(document).ready(function(){
      $(".owl-carousel").owlCarousel({
        nav:true,
        items: 1,
        margin: 15,
        loop: true
      });
      $('.image-link').magnificPopup({
        type:'image',
        gallery:{
          enabled:true
        }
      });
    });
  </script>
  <?php include './includes/end.php'; ?>
