window.addEventListener('load', function () {
  const nameLS = localStorage.getItem('cf_name');
  const emailLS = localStorage.getItem('cf_email');
  const phoneLS = localStorage.getItem('cf_phone');
  const messageLS = localStorage.getItem('cf_message');
  const addressLS = localStorage.getItem('cf_address');

  if (window.location.pathname == '/book-phone-consultation') {
    Calendly.initInlineWidget({
      url: 'https://calendly.com/contact-2939/15-minute-phone-call-main?hide_gdpr_banner=1&text_color=00394E&primary_color=1EBACA',
      parentElement: document.getElementById('calendly-widget-phone'),
      prefill: {
        name: nameLS ? nameLS : '',
        email: emailLS ? emailLS : '',
        customAnswers: {
          a1: phoneLS ? phoneLS : '',
          a2: messageLS ? messageLS : ''
        }
      },
      utm: {
        utmCampaign: "dmvfoam.com",
        utmSource:   "call"
      }
    });
  } else if (window.location.pathname == '/book-inhome-consultation.php') {
    Calendly.initInlineWidget({
      url: 'https://calendly.com/contact-2939/45-minute-house-meeting-main?hide_gdpr_banner=1&text_color=00394E&primary_color=1EBACA',
      parentElement: document.getElementById('calendly-widget-inhome'),
      prefill: {
        name: nameLS ? nameLS : '',
        email: emailLS ? emailLS : '',
        customAnswers: {
          a1: phoneLS ? phoneLS : '',
          a2: addressLS ? addressLS : '',
          a3: messageLS ? messageLS : ''
        }
      },
      utm: {
        utmCampaign: "dmvfoam.com",
        utmSource:   "inhome"
      }
    });
  }
}, false);
