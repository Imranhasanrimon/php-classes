function onClickGotoInhomeButton(e) {
  const result = proccessCF(document.getElementById('cf'));
  if (result) {
    document.location.href = 'https://dmvfoam.com/book-inhome-consultation.php';
  }
}

function onClickGotoPhoneButton(e) {
  const result = proccessCF(document.getElementById('cf'));
  if (result) {
    document.location.href = 'https://dmvfoam.com/book-phone-consultation';
  }
}

function proccessCF(formEl) {
  const nameEl = formEl.elements['name'];
  const emailEl = formEl.elements['email'];
  const phoneEl = formEl.elements['phone'];
  const messageEl = formEl.elements['message'];

  const nameAlertEl = formEl.querySelector('.cf__alert--name');
  const emailAlertEl = formEl.querySelector('.cf__alert--email');
  const phoneAlertEl = formEl.querySelector('.cf__alert--phone');
  const messageAlertEl = formEl.querySelector('.cf__alert--message');

  nameAlertEl.innerHTML = '';
  emailAlertEl.innerHTML = '';
  phoneAlertEl.innerHTML = '';
  messageAlertEl.innerHTML = '';

  const nameValidationResult = validatesName(nameEl.value);
  const emailValidationResult = validatesEmail(emailEl.value);
  const phoneValidationResult = validatesPhone(phoneEl.value);
  const messageValidationResult = validatesMessage(messageEl.value);

  if (!nameValidationResult.valid) {
    nameAlertEl.innerHTML = nameValidationResult.alertText;
  } else {
    localStorage.setItem('cf_name', nameEl.value);
  }
  if (!emailValidationResult.valid) {
    emailAlertEl.innerHTML = emailValidationResult.alertText;
  } else {
    localStorage.setItem('cf_email', emailEl.value);
  }
  if (!phoneValidationResult.valid) {
    phoneAlertEl.innerHTML = phoneValidationResult.alertText;
  } else {
    localStorage.setItem('cf_phone', phoneEl.value);
  }
  if (!messageValidationResult.valid) {
    messageAlertEl.innerHTML = messageValidationResult.alertText;
  } else {
    localStorage.setItem('cf_message', messageEl.value);
  }

  return nameValidationResult.valid && emailValidationResult.valid && phoneValidationResult.valid && messageValidationResult.valid;
}

function setUpCF(formEl) {
  const nameEl = formEl.elements['name'];
  const emailEl = formEl.elements['email'];
  const phoneEl = formEl.elements['phone'];
  const messageEl = formEl.elements['message'];

  const nameLS = localStorage.getItem('cf_name');
  const emailLS = localStorage.getItem('cf_email');
  const phoneLS = localStorage.getItem('cf_phone');
  const messageLS = localStorage.getItem('cf_message');

  if (nameLS) {
    nameEl.value = nameLS;
  }
  if (emailLS) {
    emailEl.value = emailLS;
  }
  if (phoneLS) {
    phoneEl.value = phoneLS;
  }
  if (messageLS) {
    messageEl.value = messageLS;
  }
}

function validatesName(value) {
  const result = {
    valid: true,
    alertText: ''
  };
  if (_isStringEmpty(value)) {
    result.valid = false;
    result.alertText = 'Required field.';
    return result;
  }
  if (!_isStringContainsOnlyLetters(value)) {
    result.valid = false;
    result.alertText = 'Name can only contain letters.';
    return result;
  }
  return result;
}

function validatesEmail(value) {
  const result = {
    valid: true,
    alertText: ''
  };
  if (_isStringEmpty(value)) {
    result.valid = false;
    result.alertText = 'Required field.';
    return result;
  }
  if (!_isEmailCorrect(value)) {
    result.valid = false;
    result.alertText = 'Email not correct.';
    return result;
  }
  return result;
}

function validatesPhone(value) {
  const result = {
    valid: true,
    alertText: ''
  };
  if (_isStringEmpty(value)) {
    result.valid = false;
    result.alertText = 'Required field.';
    return result;
  }
  if (!_isPhoneCorrect(value)) {
    result.valid = false;
    result.alertText = 'Phone not correct.';
    return result;
  }
  return result;
}

function validatesMessage(value) {
  const result = {
    valid: true,
    alertText: ''
  };
  if (_isStringEmpty(value)) {
    result.valid = false;
    result.alertText = 'Required field.';
    return result;
  }
  return result;
}

function _isStringEmpty(string) {
  return Boolean(!string.length);
}
function _isStringContainsOnlyLetters(string) {
  return /^[A-Za-z\s]+$/.test(string);
}
function _isPhoneCorrect(phone) {
  const re = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;
  return re.test(phone);
}
function _isEmailCorrect(email) {
  const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(String(email).toLowerCase());
}




document.addEventListener("DOMContentLoaded", function() {
  setUpCF(document.getElementById('cf'));
  //document.getElementById('goto-inhome-button').addEventListener('click', onClickGotoInhomeButton);
  document.getElementById('goto-phone-button').addEventListener('click', onClickGotoPhoneButton);
});