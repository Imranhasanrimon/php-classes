/* Navigation */
const toggleNav = (e) => {
  e.preventDefault();
  const html = document.querySelector('html');
  if (html.classList.contains('st--nav-open')) {
    html.classList.remove('st--nav-open');
  } else {
    html.classList.add('st--nav-open');
  }
};

document.querySelectorAll('.js--nav-toggler').forEach(element => {
  element.addEventListener('click', toggleNav);
});





/* Scroll to Anchor */
const scrollToAnchor = (e) => {
  e.preventDefault()
  const vw = Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0)
  const offset = vw > 959 ? 61 : 0
  const el = document.querySelector(e.target.getAttribute('href'))
  window.scroll({ top: (el.offsetTop - offset), left: 0, behavior: 'smooth' })
}

document.querySelectorAll('.scroll').forEach(anchor => {
  anchor.addEventListener('click', scrollToAnchor)
});





/* Toggle Sub Nav */
function toggleSubNav(e) {
  if (window.innerWidth < 1199) {
    e.preventDefault();
    e.target.closest('.nav-list__item').querySelector('.inner-nav-list').classList.toggle('st--active');
  }
}
window.addEventListener('load', function () {
  document.querySelector('.nav-link--toggler').addEventListener('click', toggleSubNav);
});





/* Go to In-Home page */
async function gotoInHome(e) {
  e.preventDefault();
  const redirectUrl = 'https://dmvfoam.com/book-inhome-consultation.php';
  const postUrl = '/cip.php';
  const password = prompt("Admin access:");

  if (!password) {
    alert('No password provided.');
    return;
  }

  try {
    const requestOptions = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pass: password })
    };

    const response = await fetch(postUrl, requestOptions);
    const data = await response.json();

    if (data.success) {
      window.location.href = redirectUrl;
    }
  } catch (error) {
    console.error('Error:', error);
  }
}
window.addEventListener('load', function () {
  document.querySelector('.goto-inhome').addEventListener('click', gotoInHome);
});





/* Financing Modal */
function showFinancingModal() {
  const sessionFinancingModal = sessionStorage.getItem('financing-modal');
  if (sessionFinancingModal === null) {
    document.querySelector('body').classList.add('modal-active');
    document.querySelector('#modal-container').classList.add('two');
  }
}
function hideFinancingModal(e) {
  if (e.target.className === 'modal-background' || e.target.className === 'modal-close' || e.target.className.baseVal === 'modal-close__svg' || e.target.className.baseVal === 'modal-close__use') {
    document.querySelector('#modal-container').classList.add('out');
    document.querySelector('body').classList.remove('modal-active');
    sessionStorage.setItem('financing-modal', true);
  }
}
function onClickFinancingButton(e) {
  e.preventDefault();
  window.open('https://www.enhancify.com/cdaa-inc-financing-offers', '_blank').focus();
  document.querySelector('#modal-container').classList.add('out');
  document.querySelector('body').classList.remove('modal-active');
  sessionStorage.setItem('financing-modal', true);
}

window.addEventListener('load', function () {
  document.querySelector('#modal-container').addEventListener('click', hideFinancingModal);
  document.querySelector('.modal-link').addEventListener('click', onClickFinancingButton);
  setTimeout(showFinancingModal, 55000);
});