<?php
  $curr_page = '404';
?>
  <?php include './includes/head.php'; ?>
  <meta name="description" content="Page Not Found">
  <title>DMV Foam - Page Not Found</title>
</head>
<body>
  <?php include './includes/header.php'; ?>
  <main class="main" role="main">
    <header class="page-header">
      <div class="container">
        <div class="container-inner">
          <h1>404</h1>
        </div>
      </div>
    </header>
    <section class="pre-footer">
      <div class="pre-footer__wave">
        <img src="./assets/svg/footer-wave.svg" alt="Wave">
      </div>
      <div class="pre-footer__main">
        <div class="container">
          <div class="container-inner">
            <h2 class="text-w title-big">Sorry, this URL does not exist.</h2>
            <p><a class="btn btn-big btn-blue" href="/">Home page</a></p>
          </div>
        </div>
      </div>
    </section>
  </main>
  <?php include './includes/footer.php'; ?>
  <?php include './includes/svg.php'; ?>
  <?php include './includes/end.php'; ?>
