<?php
  $curr_page = 'unsubscribe';
?>
  <?php include './includes/head.php'; ?>
  <meta name="description" content="">
  <title>Unsubscribe from our email list</title>
</head>
<body>
  <?php include './includes/header.php'; ?>
  <main class="main" role="main">
    <header class="page-header">
      <div class="container">
        <div class="container-inner">
          <h1>Unsubscribe</h1>
        </div>
      </div>
    </header>
    <section class="pre-footer">
      <div class="pre-footer__wave">
        <img src="./assets/svg/footer-wave.svg" alt="Wave">
      </div>
      <div class="pre-footer__main">
        <div class="container">
          <div class="container-inner">
            <h2 class="h3 title">Would you prefer to unsubscribe?</h2>
            <div id="content">
              <p class="mb--d">Click the button bellow to unsubscribe <span id="email-address" class="fw--700"></span><br>from messages by <span class="fw--700">DMV Foam</span>.</p>
              <p><button id="unsubscribe" class="btn btn-big btn-blue" type="button">Unsubscribe</button></p>
            </div>
            <div id="result" class="d--n">
              <p id="result-text" class="mb--d"></p>
              <button id="refresh" class="btn btn-big btn-blue" type="button">Refresh</button>
            </div>
            <div id="loading" class="d--n">Process...</div>
          </div>
        </div>
      </div>
    </section>
  </main>
  <?php include './includes/footer.php'; ?>
  <?php include './includes/svg.php'; ?>
  <script>
    const contentEl = document.querySelector('#content');
    const emailAddressEl = document.querySelector('#email-address');
    const resultEl = document.querySelector('#result');
    const resultTextEl = document.querySelector('#result-text');
    const unsubscribeButtonEl = document.querySelector('#unsubscribe');
    const refreshButtonEl = document.querySelector('#refresh');
    const loadingEl = document.querySelector('#loading');
    const pipedriveApiToken = '7ce44f29061174616279ceb558abe7ed59f2f123';
    const pipedriveCompany = 'sterlingroofers';
    const brandName = 'DMV Foam';
    let emailAddress = '';

    async function getPipedrivePersonsByEmail(emailAddress) {
      const url = `https://${pipedriveCompany}.pipedrive.com/api/v1/persons/search?api_token=${pipedriveApiToken}&term=${emailAddress}&exact_match=false`;
      const response = await fetch(url);
      return response.json();
    }

    async function getPipedriveDealsByPersonId(personId) {
      const term = "";
      const url = `https://${pipedriveCompany}.pipedrive.com/api/v1/persons/${personId}/deals?api_token=${pipedriveApiToken}`;
      const response = await fetch(url);
      return response.json();
    }

    async function updateDealNewsletterStatus(dealId) {
      const url = `https://${pipedriveCompany}.pipedrive.com/api/v1/deals/${dealId}?api_token=${pipedriveApiToken}`;
      const response = await fetch(url, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          '6eb016a615422f3776c5008f92dec872030a961a': 'Unsubscribed'
        })
      });
      return response.json();
    }

    function setResult(text) {
      contentEl.style.display = 'none';
      resultEl.style.display = 'block';
      resultTextEl.innerHTML = text;
    }

    function startLoading() {
      loadingEl.style.display = 'block';
      contentEl.style.display = 'none';
    }

    function stopLoading() {
      loadingEl.style.display = 'none';
    }

    function refresh() {
      contentEl.style.display = 'block';
      resultEl.style.display = 'none';
    }

    async function unsubscribe(e) {
      e.preventDefault();
      startLoading();
      if (!emailAddress) {
        setResult('Email address not found.');
        stopLoading();
        return;
      }

      const foundPersons = await getPipedrivePersonsByEmail(emailAddress);
      if (!foundPersons.data.items.length) {
        setResult('Person not found.');
        stopLoading();
        return;
      }
      const personId = foundPersons.data.items[0].item.id;

      const foundDeals = await getPipedriveDealsByPersonId(personId);
      if (!foundDeals.data) {
        setResult('Person not found.');
        stopLoading();
        return;
      }
      const dealId = foundDeals.data[0].id;
      
      const updateDealResponse = await updateDealNewsletterStatus(dealId);
      if (updateDealResponse.success) {
        setResult(`You have successfully unsubscribed from <span class="fw--700">${brandName}</span> messages.`);
        refreshButtonEl.style.display = 'none';
      } else {
        setResult(`Failed to unsubscribe from <span class="fw--700">${brandName}</span> messages. Please reload the page and try again.`);
      }
      stopLoading();
      return;
    }

    window.addEventListener('load', async () => {
      const searchParams = new URLSearchParams(window.location.search);
      if (searchParams.has('email')) {
        emailAddress = searchParams.get('email').trim();
        if (emailAddress) {
          emailAddressEl.innerHTML = emailAddress;
        }
      }
      unsubscribeButtonEl.addEventListener('click', unsubscribe);
      refreshButtonEl.addEventListener('click', refresh);
    });
  </script>
  <?php include './includes/end.php'; ?>
